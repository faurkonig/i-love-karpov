--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.21 (Debian 10.21-1.pgdg90+1)
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE supergames;
--
-- Name: supergames; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE supergames WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE supergames OWNER TO postgres;

\connect supergames

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: administration; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA administration;


ALTER SCHEMA administration OWNER TO postgres;

--
-- Name: internal; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA internal;


ALTER SCHEMA internal OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: admins; Type: TABLE; Schema: administration; Owner: postgres
--

CREATE TABLE administration.admins (
    id integer NOT NULL,
    login text NOT NULL,
    password text
);


ALTER TABLE administration.admins OWNER TO postgres;

--
-- Name: cart_elements; Type: TABLE; Schema: internal; Owner: postgres
--

CREATE TABLE internal.cart_elements (
    id integer NOT NULL,
    game integer NOT NULL,
    "user" integer NOT NULL,
    add_time timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE internal.cart_elements OWNER TO postgres;

--
-- Name: collection_elements; Type: TABLE; Schema: internal; Owner: postgres
--

CREATE TABLE internal.collection_elements (
    id integer NOT NULL,
    "user" integer NOT NULL,
    game integer NOT NULL,
    add_time timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE internal.collection_elements OWNER TO postgres;

--
-- Name: collection_elements_id_seq; Type: SEQUENCE; Schema: internal; Owner: postgres
--

ALTER TABLE internal.collection_elements ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME internal.collection_elements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: developers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.developers (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.developers OWNER TO postgres;

--
-- Name: games; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.games (
    id integer NOT NULL,
    developer integer NOT NULL,
    name text NOT NULL,
    description text,
    publish_time timestamp without time zone DEFAULT now() NOT NULL,
    price integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.games OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login text NOT NULL,
    password text NOT NULL,
    name text,
    register_time timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: admins; Type: TABLE DATA; Schema: administration; Owner: postgres
--

COPY administration.admins (id, login, password) FROM stdin;
\.
COPY administration.admins (id, login, password) FROM '$$PATH$$/2894.dat';

--
-- Data for Name: cart_elements; Type: TABLE DATA; Schema: internal; Owner: postgres
--

COPY internal.cart_elements (id, game, "user", add_time) FROM stdin;
\.
COPY internal.cart_elements (id, game, "user", add_time) FROM '$$PATH$$/2895.dat';

--
-- Data for Name: collection_elements; Type: TABLE DATA; Schema: internal; Owner: postgres
--

COPY internal.collection_elements (id, "user", game, add_time) FROM stdin;
\.
COPY internal.collection_elements (id, "user", game, add_time) FROM '$$PATH$$/2900.dat';

--
-- Data for Name: developers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.developers (id, email, password, name, description) FROM stdin;
\.
COPY public.developers (id, email, password, name, description) FROM '$$PATH$$/2896.dat';

--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.games (id, developer, name, description, publish_time, price) FROM stdin;
\.
COPY public.games (id, developer, name, description, publish_time, price) FROM '$$PATH$$/2897.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, login, password, name, register_time) FROM stdin;
\.
COPY public.users (id, login, password, name, register_time) FROM '$$PATH$$/2898.dat';

--
-- Name: collection_elements_id_seq; Type: SEQUENCE SET; Schema: internal; Owner: postgres
--

SELECT pg_catalog.setval('internal.collection_elements_id_seq', 1, false);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: administration; Owner: postgres
--

ALTER TABLE ONLY administration.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: cart_elements cart_elements_pkey; Type: CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.cart_elements
    ADD CONSTRAINT cart_elements_pkey PRIMARY KEY (id);


--
-- Name: collection_elements collection_elements_pk; Type: CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.collection_elements
    ADD CONSTRAINT collection_elements_pk PRIMARY KEY (id);


--
-- Name: developers developers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.developers
    ADD CONSTRAINT developers_pkey PRIMARY KEY (id);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cart_elements added by; Type: FK CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.cart_elements
    ADD CONSTRAINT "added by" FOREIGN KEY ("user") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: collection_elements added by; Type: FK CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.collection_elements
    ADD CONSTRAINT "added by" FOREIGN KEY ("user") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_elements refers to; Type: FK CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.cart_elements
    ADD CONSTRAINT "refers to" FOREIGN KEY (game) REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: collection_elements refers to; Type: FK CONSTRAINT; Schema: internal; Owner: postgres
--

ALTER TABLE ONLY internal.collection_elements
    ADD CONSTRAINT "refers to" FOREIGN KEY (game) REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: games developed by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "developed by" FOREIGN KEY (developer) REFERENCES public.developers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

